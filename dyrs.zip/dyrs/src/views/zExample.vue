<template>
	<div>
		<div class="zzex">
		<div class="zex">
			<div class="lzex">
				<div class="lzex-1">
					<p>当前位置&nbsp;&nbsp;：</p>
					<p>首页>装修案例><span>{{vl.fields.title}}-</span><span>{{vl.fields.case_area}}平米-</span><span>{{vl.fields.case_style}}</span></p>
				</div>
				<div class="lzex-2">
					<h1>{{vl.fields.title}}-{{vl.fields.case_area}}平米-{{vl.fields.case_style}}</h1>
					<p><span>来源: 东易日盛装饰</span>&nbsp;&nbsp;
					<span>浏览人数: {{vl.fields.count}}次</span>&nbsp;&nbsp;
					<span>更新时间: {{vl.fields.update_time}}</span></p>
				</div>
				<div class="lzex-3">
					<ul><li>
						<p>{{vl.fields.case_style}}</p>
						<p>案例风格</p>
					</li>
					<li>
						<p>{{vl.fields.case_type}}</p>
						<p>案例户型</p>
					</li>
					<li>
						<p>{{vl.fields.case_area}}平米</p>
						<p>案例面积</p>
					</li>
					<li>
						<p>{{vl.fields.floor_name?vl.fields.floor_name:'--'}}</p>
						<p>楼盘名称</p>
					</li>
					<li>
						<p>{{vl.fields.case_city}}</p>
						<p>所在城市</p>
					</li>
					<li>
						<p>{{vl.fields.designer.fields.name}}</p>
						<p>设计师</p>
					</li></ul>
				</div>
				<div class="lzex-4">
					<div class="lzex-41">
						<h1>设计理念</h1>
						 <p>{{vl.fields.design_reason}}</p>
					</div>
					<div class="lzex-42"><img :src="vl.fields.house_type_pic" alt=""></div>
				</div>
			</div>
			<div class="rzex"></div>
		</div>
		</div>
	</div>
</template>

<script>
	export default{
		data(){
			return{
				vl: ""
			}
		},
		mounted(){
			var zthat = this
			let zid = this.$route.params.h_id
			this.http.get("http://www.moblie.site:88/case_detail/",{
				params:{
					cid: zid
				}
			}).then(zresp => {
				console.log(zresp)
				zthat.vl = zresp.data.data
			})
			
		}
	}
</script>

<style scoped>
	body{
		margin: 0;
	}
	ul{
		margin: 0;
		padding: 0;
	}
	li{
		list-style: none;
	}
	.zzex{
		width: 100vw;
		margin-top: 23vh;
		background: lightgray;
	}
	.zex{
		width: 60vw;
		margin: 0 auto;
	}
	.lzex{
		width: 44vw;
	}
	.rzex{
		width: 15vw;
	}
	.lzex-1{
		width: 44vw;
		height: 60px;
		margin: 0 auto;
		display: flex;
		align-items: center;
		font-size: 15px;
	}
	
	.lzex-1>p {
		margin-right: 0.5vw;
	}
	.lzex-2{
		width: 44vw;
		height: 70px;
	}
	.lzex-2>h1{
		margin: 0;
		height: 40px;
		line-height: 40px;
		font-size: 20px;
		text-align: center;
	}
	.lzex-2>p{
		margin: 0;
		height: 30px;
		line-height: 30px;
		text-align: center;
		font-size: 15px;
	}
	.lzex-3{
		width: 44vw;
		height: 200px;
		margin-top: 2vh;
		display: flex;
		justify-content: center;
		align-items: center;
		border: 1px solid white;
		box-shadow:0 0 5px white ;
	}
	.lzex-3>ul{
		width: 37.5vw;
		height: 160px;
		display: flex;
		flex-wrap: wrap;
	}
	.lzex-3>ul>li{
		width: 12.5vw;
		padding-top: 25px;
		height: 80px;
		text-align: center;
		font-size: 15px;
		border-bottom: 1px solid white;
	}
	.lzex-4{
		width: 44vw;
		height: 350px;
		margin-top: 4vh;
		display: flex;
		justify-content: space-around;
	}
	.lzex-41{
		width: 20vw;
		height: 350px;
		display: flex;
		flex-direction: column;
		justify-content: space-around;
	}
	.lzex-41>h1{
		height: 30px;
		width: 4.5vw;
        text-align: left;
		line-height: 30px;
		font-size: 20px;
		border-bottom: 1px solid red;
	}
	.lzex-41>p{
		height: 220px;
		text-align: left;
		font-size: 15px;
	}
	.lzex-42{
		width: 20vw;
		height: 350px;
		background-color: #DA70D6
	}
	.lzex-42>img{
		width: 100%;
		height: 100%;
	}
</style>
