<template>
	<div>
		<div class="ins">
			<div class="ins-1">
				<p>当前位置&nbsp;&nbsp;：</p>
				<p>首页>设计大师><span>{{dmess.fields.name}}</span><span>{{dmess.fields.job_title}}</span></p>
			</div>
			<div class="ins-2">
				<section class="ins-21">
					<img :src="dmess.fields.pic" alt="">
				</section>
				<section class="ins-22">
					<p class="ins-221"><span>{{dmess.fields.name}}</span><span>{{dmess.fields.job_title}}</span></p>
					<div class="ins-222">
						<ul>
							<li class="ins-2221">
								<p>从业经验:{{dmess.fields.exp}}年</p>
								<p>案例作品：</p>
							</li>
							<li>擅长户型：{{dmess.fields.house_type}}</li>
							<li>店面地址:</li>
						</ul>
						<ul>
							<li>擅长风格: {{dmess.fields.good_at}}</li>
							<li>所在店面:</li>
						</ul>
					</div>
					<div class="ins-223">
						<section class="ins-2231">
							<p>个人</p>
							<p>简介</p>
						</section>
						<section class="ins-2332">
							<p>设计理念：</p>
							<p v-for="k in dmess.fields.awards.split('\n')">{{k}}</p>
						</section>
					</div>
				</section>
			</div>
		</div>
		<div class="dnav-2">
			<ul>
				<li>相关案例</li>
				<li>户型解析</li>
				<li>在施工地</li>
				<li>在职门店</li>
			</ul>
		</div>
		<div class="zps">
			<section>
				<p>相关案例</p>
				<div>
					<section><img src="" alt=""></section>
					<section>
						<p></p>
						<p></p>
						<div><img src="" alt=""></div>
					</section>
				</div>
			</section>
			<section>
				<p>户型解析</p>
				<div>
					<section><img src="" alt=""></section>
					<section>
						<p></p>
						<p></p>
						<div><img src="" alt=""></div>
					</section>
				</div>
			</section>
			<section>
				<p>在施工地</p>
				<div>
					<section><img src="" alt=""></section>
					<section>
						<p></p>
						<p></p>
						<div><img src="" alt=""></div>
					</section>
				</div>
			</section>
			<section>
				<p>在职门店</p>
				<div>
					<section><img src="" alt=""></section>
					<section>
						<p></p>
						<p></p>
						<div><img src="" alt=""></div>
					</section>
				</div>
			</section>
		</div>

	</div>
</template>

<script>
	export default {
		data() {
			return {
				vr: '',
				dmess: ""
			}
		},
		mounted() {
			var ddthat = this
			let pid = this.$route.params.d_id
			this.http.get("http://www.moblie.site:88/designer_detail/", {
					params: {
						did: pid
					}
				}).then(ddresp => {
					ddthat.dmess = ddresp.data.data.designer
					console.log(ddresp)
				}),
				this.http.get("http://www.moblie.site:88/case/")
				.then(dtresp => {
					console.log(dtresp)
				})

		}
	}
</script>

<style scoped>
	body {
		margin: 0;
	}

	p {
		margin: 0;
	}

	ul {
		margin: 0;
		padding: 0;
	}

	li {
		list-style: none;
	}

	.ins {
		margin-top: 23vh;
		width: 100vw;
		height: 570px;
		background: whitesmoke;
	}

	.ins-1 {
		width: 60vw;
		height: 60px;
		margin: 0 auto;
		display: flex;
		align-items: center;
		font-size: 15px;
	}

	.ins-1>p {
		margin-right: 0.5vw;
	}

	.ins-2 {
		width: 60vw;
		height: 470px;
		margin: 0 auto;
		background: white;
		display: flex;
		align-items: center;
	}

	.ins-21 {
		width: 24vw;
		height: 460px;
	}

	.ins-21 img {
		width: 100%;
		height: 100%;
	}

	.ins-22 {
		margin-left: 2vw;
		width: 34vw;
		height: 460px;
	}

	.ins-221 {
		height: 40px;
		line-height: 40px;
		font-size: 15px;
	}

	.ins-222 {
		width: 34vw;
		height: 180px;
		display: flex;
		justify-content: space-between;
		padding-top: 20px;
	}

	.ins-222>ul {
		width: 16vw;
		height: 180px;
		font-size: 15px;
	}

	.ins-222>ul>li {
		margin-top: 5px;
		width: 16vw;
		overflow: hidden;
		white-space: nowrap;
		text-overflow: ellipsis;
	}

	.ins-2221 {
		display: flex;

	}

	.ins-2221>p {
		width: 8.5vw;
	}

	.ins-223 {
		width: 34vw;
		height: 240px;
		overflow-x: hidden;
		overflow-y: scroll;
		font-size: 15px;
	}

	.ins-2231 {
		width: 34vw;
		height: 40px;
		display: flex;
		align-items: center;

	}

	.ins-2231>p:nth-of-type(1) {
		border-bottom: 1px solid red;
	}

	.dnav-2 {
		width: 60vw;
		height: 60px;
		line-height: 60px;
		font-size: 20px;
		margin: 0 auto;
		position: sticky;
		
	}

	.dnav-2>ul {
		height: 60px;
		display: flex;
		align-items: center;

	}

	.dnav-2>ul>li {
		margin-right: 1vw;
	}
	.zps{
		width: 60vw;
		margin: 0 auto;
	}
	.zps>section{
		width: 60vw;
		
	}
	.zps>section>p{
		
		height: 60px;
		font-size: 20px;
	}
	.zps>section>div{
		width: 60vw;
		height: 240px;
	}
</style>
