<template>
	<div class="ali">
		<div class="anav">
			<section class="anav-1">
				<img src="../assets/nimages/al.01.jpg" alt="">
			</section>
		</div>
		<div class="add">
			<section class="add-1">
				<div class="add-11">
					<p><span>当前位置 ：</span>
						<span>首页></span>
						<span>装修案例</span></p>
				</div>
				<div class="add-12">
					<p>共<span style="color: red;">31826</span>套装修案例</p>
				</div>
			</section>
			<section class="add-2">更多选项</section>
		</div>
		<div class="selec">
			<section>
				<p>案例属性</p>
				<ul>
					<li class="fir">全部</li>
					<li>效果图</li>
					<li>实景图</li>
				</ul>
			</section>
			<section>
				<p>案例户型</p>
				<ul>
					<li :class="{fir:cyshow == -1}" @click="zhan('', -1)">全部</li>
					<li v-for="(cy, inx) in ctypeArr" :class="{fir:cyshow == inx}" @click="zhan(cy.fields.name, inx)">{{cy.fields.name}}</li>
				</ul>
			</section>
			<section>
				<p>装修风格</p>
				<ul>
					<li :class="{fir:csshow == -1}" @click="chan('', -1)">全部</li>
					<li v-for="(cs, icx) in cstyleArr" :class="{fir:csshow == icx}" @click="chan(cs.fields.name, icx)">{{cs.fields.name}}</li>
				</ul>
			</section>
			<section>
				<p>房屋面积</p>
				<ul>
					<li class="fir">全部</li>
					<li>120平米以下</li>
					<li>121-180平米</li>
					<li>181-320平米</li>
				</ul>
			</section>
			<section>
				<p>所属分站</p>
				<ul>
					<li class="fir">全部</li>
					<li>北京</li>
					<li>北京别墅</li>
					<li>北京家居体验馆</li>
				</ul>
			</section>
		</div>
		<div class="dselec">
			<section class="dselec-1">
				<p>最新</p>
				<p>人气</p>
			</section>
			<section class="dselec-2">
				<Select v-model="val" style="width:100px" :placeholder="list1[0]">
					<Option v-for="item in list1" :value="item" :key="item">{{item}}</Option>
				</Select>
				<Select v-model="val" style="width:100px" :placeholder="list1[0]">
					<Option v-for="item in list1" :value="item" :key="item">{{item}}</Option>
				</Select>
				<Select v-model="val" style="width:100px" :placeholder="list1[0]">
					<Option v-for="item in list1" :value="item" :key="item">{{item}}</Option>
				</Select>
				<Select v-model="val" style="width:100px" :placeholder="list1[0]">
					<Option v-for="item in list1" :value="item" :key="item">{{item}}</Option>
				</Select>
				<Select v-model="val" style="width:100px" :placeholder="list1[0]">
					<Option v-for="item in list1" :value="item" :key="item">{{item}}</Option>
				</Select>
			</section>
			<section class="dselec-3"><input type="text" placeholder="关键字"><button>搜索</button></section>
		</div>
		<div class="workshow">
			<ul class="workshow-1">
				<router-link v-for="l in arArr" :to="'/aLi/zExample/' + l.pk">
					<li>
						<section class="workshow-11">
							<div class="workshow-111">我也要设计成这样</div>
							<div class="workshow-112">收藏</div>
							<div class="workshow-113">17 752</div>
							<img :src="l.fields.pic" alt="">
						</section>
						<section class="workshow-12">
							<div class="workshow-121"><img :src="l.fields.designer.fields.pic" alt=""></div>
							<div class="workshow-122">
								<p>{{l.fields.title}}</p>
								<p>{{l.fields.case_type}}|{{l.fields.case_style}}|{{l.fields.case_area}}平米</p><button>找他设计</button>
							</div>
						</section>
					</li>
				</router-link>
			</ul>
		</div>
		<div class="test"></div>
	</div>
</template>

<script>
	export default {
		data() {
			return {
				val: "",
				list1: ["全部属性", "全景图", "效果图"],
				arArr: [],
				ctypeArr: [],
				cstyleArr: [],
				htype: "",
				hstyle: "",
				cyshow: -1,
				csshow: -1
			}
		},
		mounted() {
			var athat = this
			this.http.get("http://www.moblie.site:88/ctype/")
				.then(ctresp => {
					console.log(ctresp)
					athat.ctypeArr = ctresp.data.data
				}),
				this.http.get("http://www.moblie.site:88/cstyle/")
				.then(csresp => {
					console.log(csresp)
					athat.cstyleArr = csresp.data.data
				}),
				this.http.get("http://www.moblie.site:88/case/")
				.then(aresp => {
					console.log(aresp)
					athat.arArr = aresp.data.data

				})
		},
		methods: {
			zhan(x, y) {
				let zn = this
				zn.cyshow = y
				zn.htype = x
				this.http.get("http://www.moblie.site:88/case/", {
						params: {
							ctype: zn.htype,
							cstyle: zn.hstyle

						}
					})
					.then(aresp => {
						console.log(aresp)
						zn.arArr = aresp.data.data

					})

			},
			chan(x, y) {

				let cn = this
				cn.csshow = y
				cn.hstyle = x
				this.http.get("http://www.moblie.site:88/case/", {
						params: {
							ctype: cn.htype,
							cstyle: cn.hstyle

						}
					})
					.then(aresp => {
						console.log(aresp)
						cn.arArr = aresp.data.data

					})

			}



		}
	}
</script>

<style scoped>
	* {
		box-sizing: border-box;
		overflow: hidden;
	}

	body {
		margin: 0;
	}

	ul {
		margin: 0;
		padding: 0;
	}

	li {
		list-style: none;
	}

	p {
		margin: 0;
	}

	a {
		color: black
	}

	a:hover {
		color: red;
	}

	.ali {
		background: lightgray;
	}

	.anav {
		width: 100vw;
		height: 175px;
		margin-top: 23vh;
		padding-top: 8px;
		display: flex;
		align-items: center;
	}

	.anav-1 {
		width: 60vw;
		height: 100px;
		margin: 0 auto;
		display: flex;
		justify-content: center;
		align-items: center;
		background: #DA70D6;
	}

	.anav-1 img {
		width: 100%;
		height: 100%;
	}

	.add {
		width: 60vw;
		height: 65px;
		margin: 0 auto;
		display: flex;
		justify-content: space-between;
		align-items: center;
	}

	.add-1 {
		width: 20vw;
		height: 65px;
		display: flex;
		justify-content: space-between;
		align-items: center;
		font-size: 15px;
	}

	.add-2 {
		font-size: 15px;
	}

	.selec {
		width: 60vw;
		height: 250px;
		margin: 0 auto;
	}

	.selec>section {
		width: 60vw;
		height: 50px;
		line-height: 50px;
		text-align: center;
		font-size: 15px;
		display: flex;
		cursor: pointer;
		border: 1px solid white;
	}

	.selec>section>p {
		width: 5vw;
		height: 50px;
		background: white;
		border-bottom: 2px solid lightgray !important;
	}

	.selec>section>ul {
		width: 55vw;
		height: 50px;
		display: flex;
		align-items: center;
	}

	.selec>section>ul>li {
		margin-left: 1vw;
	}

	.fir {
		height: 25px;
		line-height: 25px;
		color: white !important;
		background: red !important;
	}

	.dselec {
		width: 60vw;
		height: 60px;
		margin: 0 auto;
		display: flex;
		justify-content: space-between;
		background: white;
	}

	.dselec-1 {
		width: 5vw;
		height: 60px;
		display: flex;
		justify-content: space-around;
		align-items: center;
		font-size: 15px;
	}

	.dselec-2 {
		width: 35vw;
		height: 60px;
		display: flex;
		justify-content: space-between;
		align-items: center;
	}

	.dselec-3 {
		width: 15vw;
		height: 60px;
		display: flex;
		justify-content: center;
		align-items: center;
	}

	.dselec-3>input {
		width: 150px;
		height: 30px;
		border: none;
		outline: none;
		text-indent: 1em;
	}

	.dselec-3>button {
		width: 50px;
		height: 30px;
		border: none;
		outline: none;
		color: white;
		background: red;
		text-align: center;
	}

	.workshow {
		margin-top: 1vh;
	}

	.workshow-1 {

		width: 60vw;
		margin: 0 auto;
		display: flex;
		flex-wrap: wrap;
		align-items: center;
	}

	.workshow-1 li {
		width: 14vw;
		height: 340px;
		margin-top: 1vw;
		margin-right: 1vw;
	}

	.workshow-11 {
		width: 14vw;
		height: 225px;
		position: relative;
	}

	.workshow-11 img {
		width: 100%;
		height: 100%;
	}

	.workshow-111 {
		width: 8vw;
		height: 25px;
		line-height: 25px;
		position: absolute;
		top: 10px;
		left: 0;
		text-indent: 1em;
		color: white;
		font-size: 13px;
		background: red;
	}

	.workshow-112 {
		width: 3vw;
		height: 25px;
		line-height: 25px;
		color: white;
		font-size: 13px;
		text-align: center;
		position: absolute;
		background: rgba(0, 0, 0, 0.5);
		top: 10px;
		right: 1vw;
		border-radius: 10px;
	}

	.workshow-113 {
		width: 6vw;
		height: 25px;
		line-height: 25px;
		color: white;
		font-size: 13px;
		text-align: center;
		position: absolute;
		background: rgba(0, 0, 0, 0.5);
		bottom: 10px;
		left: 0.5vw;
		border-radius: 10px;
	}

	.workshow-12 {
		margin: 0 auto;
		width: 14vw;
		height: 115px;
		display: flex;
		background: white;
		justify-content: space-around;
		align-items: center;
	}

	.workshow-121 {
		width: 4vw;
		height: 70px;
		border-radius: 5px;

	}

	.workshow-121 img {
		width: 100%;
		height: 100%;
	}

	.workshow-122 {
		width: 8vw;
		height: 80px;
		display: flex;
		flex-direction: column;
		align-items: flex-start;
		justify-content: center;
		font-size: 15px;
	}

	.workshow-122>p {
		width: 8vw;
		height: 20px;
		line-height: 20px;
		font-size: 15px;
		overflow: hidden;
		white-space: nowrap;
		text-overflow: ellipsis;

	}

	.workshow-122>button {
		width: 4vw;
		height: 30px;
		font-size: 15px;
		text-align: center;
		line-height: 20px;
		border: 1px solid red;
		background: none;
		outline: none;
	}

	.test {
		height: 10vh;
	}
</style>
