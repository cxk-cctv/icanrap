<template>
	<div class="home">
		
		<!-- 轮播图 -->
		<div class="banner">
			 <Carousel autoplay 
			           v-model="value"  
								 arrow="always"
								 loop>
        <CarouselItem v-for="x in bannerArr">
            <div class="demo-carousel"><img :src="x.fields.img_src" alt=""></div>
        </CarouselItem>
    </Carousel>
		</div>
		<div class="message">
			<div class="message-1">
				<div class="message-11">
					<h4>免费获取家装报价</h4>
					<p>现累计已有<span style="color: red;">[14271]</span>位获取</p>
				</div>
				<div class="message-12">
					<input type="text" placeholder="你的称呼">
					<input type="text" placeholder="你的联系方式">
					<input type="text" placeholder="小区/楼盘名称">
					<input type="text" placeholder="房屋面积">
					<button>免费获取报价</button>
				</div>
			</div>
			<div class="message-2">
				   <ul class="message-21">
					 <li v-for="i in 5" @mouseenter="fg(i)">
					<h1>22年</h1>
					 <p>22年家装经验</p>
					 <p>引导国内家装潮流</p>
					 <p class="mdot"  :class="{active: i == inx }"></p></li>
					 </ul>
			</div>
		</div>
		<div class="article">
			<div class="article-1">
				<h1>甄选家装服务产品</h1>
				<p>选择东易日盛装修，更是选择对品质的追求</p>
			</div>
			<ul class="article-2">
			<li class="article-21">
				<img src="../assets/nimages/dyrs01.jpg" alt="">
				<div><h2>别墅大宅</h2>
				     <p>高端私人订制整装服务</p>
				     <p>为别墅大宅人群提供全系统生活方式解决方案，基于大师设计和管家式服务，让家恒久品质如新。</p>
						 <button>查看详情</button></div>
			</li>
			<li><img src="../assets/nimages/dyrs02.jpg" alt="">
				<div><h2>别墅大宅</h2>
				     <p>高端私人订制整装服务</p>
				     <p>为别墅大宅人群提供全系统生活方式解决方案，基于大师设计和管家式服务，让家恒久品质如新。</p>
						 <button>查看详情</button></div></li>
			<li><img src="../assets/nimages/dyrs03.jpg" alt="">
				<div><h2>别墅大宅</h2>
				     <p>高端私人订制整装服务</p>
				     <p>为别墅大宅人群提供全系统生活方式解决方案，基于大师设计和管家式服务，让家恒久品质如新。</p>
						 <button>查看详情</button></div></li>
			<li><img src="../assets/nimages/dyrs04.jpg" alt="">
				<div><h2>别墅大宅</h2>
				     <p>高端私人订制整装服务</p>
				     <p>为别墅大宅人群提供全系统生活方式解决方案，基于大师设计和管家式服务，让家恒久品质如新。</p>
						 <button>查看详情</button></div></li></ul>
			<ul class="article-3">
			  <li><section><Icon type="md-albums" /></section>
				 <h2>优惠活动</h2>
				 <p>参与优惠活动享装修大惊喜</p></li>
			  <li><section><Icon type="logo-apple" /></section>
				 <h2>免费专车</h2>
				 <p>简单预约悠享专车接您到店</p></li></li>
			  <li><section><Icon type="ios-analytics-outline" /></section>
				 <h2>免费上门验房</h2>
				 <p>验房师为您排除家装隐患</p></li></li>
			  <li><section><Icon type="ios-clipboard-outline" /></section>
				 <h2>家装贷款</h2>
				 <p>让您的美好家居梦想一步到位</p></li></li>
			</ul>
		</div>
		<div class="enjoy">
			<div class="enjoy-1">
				<h1>家装案例品鉴</h1>
				<p>10余种潮流家装风格，数万套精品案例作品，设计师精心点评，让您快速找到家装灵感</p>
			</div>
			<ul class="enjoy-2"><li><a href="">地中海式</a><i>/</i></li>
			<li><a href="">现代简约</a><i>/</i></li>
			<li><a href="">欧式古典</a><i>/</i></li>
			<li><a href="">新中式</a><i>/</i></li>
			<li><a href="">法式</a><i>/</i></li>
			<li><a href="">美式乡村</a><i>/</i></li>
			<li><a href="">北欧风格</a><i>/</i></li>
			<li><a href="">全部</a><i>/</i></li></ul>
		
		<div class="enjoy-3">
			<section class="enjoy-31">
				<router-link to="/aLi"><img :src="enjoyArr[0].fields.pic" alt=""></router-link>
			</section>
			<ul class="enjoy-32">
				<li v-for="u in enjoyArr.slice(1)"><router-link to="/aLi"><img :src="u.fields.pic" alt=""></router-link></li>
			</ul>
		</div>
		<ul class="enjoy-4">
			<li><a href="">
					<Icon></Icon>
					<p>客厅</p>
				</a></li>
			<li><a href="">
					<Icon></Icon>
					<p>卧室</p>
				</a></li>
			<li><a href="">
					<Icon></Icon>
					<p>餐厅</p>
				</a></li>
			<li><a href="">
					<Icon></Icon>
					<p>厨房</p>
				</a></li>
			<li><a href="">
					<Icon></Icon>
					<p>卫生间</p>
				</a></li>
			<li><a href="">
					<Icon></Icon>
					<p>阳台</p>
				</a></li>
			<li><a href="">
					<Icon></Icon>
					<p>书房</p>
				</a></li>
			<li><a href="">
					<Icon></Icon>
					<p>儿童房</p>
				</a></li>
			<li><a href="">
					<Icon></Icon>
					<p>更多</p>
				</a></li>
		</ul>
		</div>
		<div class="artist">
			<div class="enjoy-1">
				<h1>家装设计大师推荐</h1>
				<p>家装是一门科学，只有专业设计才不辜负“家”的期望，选对设计师才能让您的家居生活大放异彩</p>
			</div>
			<ul class="enjoy-2">
			<li><a href="">别墅大宅设计师</a><i>/</i></li>
			<li><a href="">大平层设计师</a><i>/</i></li>
			<li><a href="">公寓派设计师</a><i>/</i></li>
			<li><a href="">跃层设计师</a><i>/</i></li>
			<li><a href="">会所设计师</a><i>/</i></li>
			<li><a href="">小户型设计师</a><i>/</i></li>
			<li><a href="">全部设计师</a><i>/</i></li></ul>
			<div class="artist-1">
				<section class="artist-11">
					   <router-link :to="'/Home/dDesigin/'+ designerArr[0].pk"><img :src="designerArr[0].fields.pic" alt=""></router-link>  
				</section>
				<ul class="artist-12">
					<li v-for="t in designerArr.slice(1, 7)"><router-link :to="'/Home/dDesigin/'+ t.pk"><img :src="t.fields.pic" alt=""></router-link></li>
				</ul>
			</div>	
		</div>
		<div class="foot">
			<section class="foot-1">
				<section class="foot-11">
					<img src="../assets/logo.png" alt="">
				</section>
				<section class="foot-12">
					<section>
						<p>关于我们</p>
						<ul><li>官方微博</li>
						<li>联系我们</li>
						<li>网站地图</li>
						<li>美团官网</li></ul>
					</section>
					<section>
						<p>装修服务</p>
						<ul><li>在线预约</li>
						<li>免费家装报价</li>
						<li>免费户型规划</li>
						<li>团装优惠</li></ul>
					</section>
					<section>
						<p>在线商城</p>
						<ul><li>天猫旗舰店</li>
						<li>京东旗舰店</li>
						<li>淘宝旗舰店</li></ul>
					</section>
					<section>
						<p>联系我们</p>
						<ul><li>家装咨询：4009929518</li>
						<li>投诉建议：0371-55017950</li>
						<li>媒体合作：55017953</li>
						<li>公司地址：郑州市郑东新区CBD商务外环</li>
						<li>与东二街交叉口农信大厦 查看更多>></li></ul>
					</section>
					<section>
						<p>在线咨询</p>
						<p>QQ咨询</p>
						<p><img src="" alt="">
						 东易日盛公众号</p>
					</section>
				</section>
			</section>
			<hr>
		</div>
	</div>
</template>

<script>
	export default {
   data(){
		 return{
			 value:0,
			 bannerArr: [],
			 enjoyArr: [],
			 designerArr: [],
			 inx: 1
		 }
	 },
	 mounted(){
		 var hthat = this
		 // 轮播图请求
		 this.http.get("http://www.moblie.site:88/banner/")
		          .then(bresp =>{
								 hthat.bannerArr = bresp.data.data
							}),
			this.http.get(" http://www.moblie.site:88/case_recommend/")
			         .then(eresp =>{
								 hthat.enjoyArr = eresp.data.data
								 
							 }),
			this.http.get("http://www.moblie.site:88/designer/")
			         .then(dresp =>{
								 console.log(dresp)
								 hthat.designerArr = dresp.data.data
							 })
		 
	 },
	 methods:{
		 fg(i){
			 this.inx = i
			 console.log("....")
		 }
	 }
	}
</script>
<style scoped>
	/* 通用样式 */
	* {
		box-sizing: border-box;
	}

	body {
		margin: 0;
	}

	ul {
		margin: 0;
		padding: 0;
	}

	li {
		list-style: none;
	}

	p {
		margin: 0;
	}
	/* 轮播图 */
	.banner{
		width: 100vw;
		height: 60vh;
		background: wheat;
		margin-top: 23vh;
	}
	.ivu-carousel{
		width: 100vw;
		height: 60vh;
	}
	.demo-carousel>img{
		display: block;
		width: 100vw;
		height: 60vh;
	}
	/* 信息统计 */
	.message{
		width: 100vw;
		height: 60vh;
		padding-top: 2vh;
		background: lightgray;
	}
	/* 信息统计块1 */
	.message-1{
		width: 60vw;
		height: 30vh;
		margin: 0 auto;
		background: white;
		padding-top: 5vh;
	}
	.message-11{
		width: 60vw;
		height: 10vh;
		display: flex;
		align-items: baseline;
	}
	.message-11>h4{
		width: 15vw;
		margin: 0;
		height: 10vh;
		text-indent: 1em;
		text-align: left;
		line-height: 10vh;
		font-size: 1vw;
	}
	.message-11>p{
		  width: 10vw;
			height: 10vh;
		  line-height: 10vh;
			font-size: 0.8vw;
	}
	.message-12{
		width: 60vw;
		height: 10vh;
		display: flex;
		justify-content: space-between;
		align-items: center;
	}
	.message-12>input{
		width: 10vw;
		height: 6vh;
		text-indent: 1em;
		line-height: 6vh;
		border: none;
		outline: none;
		background: whitesmoke;
		
	}
	.message-12>button{
		width: 8vw;
		height: 6vh;
		text-align: center;
		line-height: 6vh;
		border: none;
		background: red;
		color: white;
		outline: none;
	}
	/* 信息统计块2 */
	.message-2{
		width: 100vw;
		height: 25vh;
		background: whitesmoke;
	}
	.message-21{
		width: 60vw;
		height: 25vh;
		margin: 0 auto;
		display: flex;
		justify-content: space-between;
		align-items: center;
		background: whitesmoke;
	}
	.message-21>li{
		width: 10vw;
		height: 15vh;
		background: white;
		position: relative;
	}
	.message-21>li>h1{
		margin: 0;
		width: 10vw;
		height: 8vh;
		line-height: 8vh;
		text-align: left;
		text-indent: 1em;
	}
	.message-21>li>p{
		width: 8vw;
		height: 3.5vh;
		line-height: 3.5vh;
		text-align: left;
		text-indent: 1em;
	}
	.mdot{
		position: absolute;
		width: 1.2vh !important;
		height: 1.2vh !important;
		border-radius: 50%;
		background: whitesmoke;
		top: 1.5vh;
		left: 9vw;
	}
	.active{
		background: orangered !important;
	}
	.article{
		width: 100vw;
		
		background: lightgray;
	}
	.article-1{
		width: 60vw;
		height: 10vh;
		margin: 0 auto;
		
	}
	.article-1>h1{
		width: 60vw;
		height: 6vh;
		line-height: 6vh;
		text-align: center;
		font-size: 1.5vw;
	}
	.article-1>p{
		width: 60vw;
		height: 4vh;
		text-align: center;
		line-height: 4vh;
		font-size: 0.8vw;
	}
	.artist-1 img{
		width: 100%;
		height: 100%;
	}
	.article-2{
		width: 60vw;
		height: 40vh;
		margin: 0 auto;
		display: flex;
		justify-content: space-between;
		align-items: center;
	}
	.article-2>li{
		width: 14vw;
		height: 40vh;
		background: wheat;
		color: white;
		position: relative;
	}
	.article-21{
		width: 17vw !important;
		height: 40vh;
	}
	.article-21 img{
		width: 100%;
		height: 100%;
	}
	.article-2>li>div{
		width: 100%;
		height: 25vh;
		position: absolute;
		bottom: 0;
		text-align: left;
		display: flex;
		flex-direction: column;
		justify-content: center;
	}
	.article-2 img{
		width: 100%;
		height: 100%;
	}
	.article-2>li>div h2{
		width: 90%;
		height: 6vh;
		line-height: 6vh;
		margin-left: 5%;
		font-size: 1.3vw;
		font-weight: 500;
		
	}
	.article-2>li>div>p:nth-of-type(1){
		width: 90%;
		height: 5vh;
		line-height: 5vh;
		margin-left: 5%;
		font-size: 18px;
	}
	.article-2>li>div>p:nth-of-type(2){
		width: 90%;
		height: 8vh;
		margin-left: 5%;
		font-size: 0.7vw;
		
	}
	.article-2>li>div>button{
		width: 40%;
		height: 4vh;
		margin-left: 5%;
		text-align: center;
		line-height: 4vh;
		font-size: 0.8vw;
		border: none;
		outline: none;
		background: white;
		
	}
	.article-2>li>div>button:hover{
		background: red;
	}
	.article-3{
		width: 60vw;
		height: 15vh;
		margin: 0 auto;
		margin-top: 2vh;
		display: flex;
		justify-content: space-around;
		align-items: center;
	}
	.article-3>li{
		width: 12vw;
		height: 15vh;
		display: flex;
		flex-direction: column;
		justify-content: space-around;
		align-items: center;
	}
	.article-3>li>section{
		width: 8vh;
		height: 8vh;
		font-size: 1.5vw;
		text-align: center;
		line-height: 8vh;
		border-radius: 50%;
		border: 1px solid black;
	}
	.article-3>li>section:hover{
		background: #FF4500;
	}
	.article-3>li>h2{
		font-weight: 500;
	}
  .enjoy{
		width: 100vw;
		height: 100vh;
	}
	.enjoy-1{
		width: 100vw;
		height: 20vh;
	}
	.enjoy-1>h1{
		width: 60vw;
		height: 12vh;
		text-align: center;
		line-height: 12vh;
		margin: 0 auto;
		font-size: 1.3vw;
	}
	.enjoy-1>p{
		width: 60vw;
		height: 8vh;
		line-height: 8vh;
		text-align: center;
		margin: 0 auto;
		font-size: 0.9vw;
	}
	.enjoy-2{
		width: 60vw;
		height: 15vh;
		margin: 0 auto;
		display: flex;
		justify-content: center;
		align-items: center;
	}
	.enjoy-2>li{
		width: 7vw;
		height: 15vh;
		line-height: 15vh;
		text-align: left;
		display: flex;
		justify-content: center;
		align-items: center;
		font-size: 0.7vw;
		cursor: pointer;
	}
	.enjoy-2>li>i{
		width: 2vw;
		display: inline-block;
		text-align: center;
	}
	.enjoy-2 a{
		color: black;
	}
	.enjoy-2 a:hover{
		color: red;
	}
	.enjoy-3{
		width: 60vw;
		height: 40vh;
		margin: 0 auto;
		display: flex;
		justify-content: space-between;
	}
	.enjoy-31{
		width: 14vw;
		height: 40vh;
		background: #42B983;
	}
	.enjoy-31 img{
		width: 100%;
		height: 100%;
	}
	.enjoy-32{
		width: 45vw;
		height: 40vh;
		display: flex;
		justify-content: space-between;
		flex-wrap: wrap;
		align-items: center;
	}
	.enjoy-32 img{
		width: 100%;
		height: 100%;
	}
	.enjoy-32>li{
		width: 14vw;
		height: 19vh;
			background: #42B983;
	}
	.enjoy-4{
		width: 60vw;
		height: 15vh;
		margin: 0 auto;
		display: flex;
		justify-content: space-between;
		align-items: center;
	}
	.enjoy-4>li{
		width: 10vh;
		height: 10vh;
		text-align: center;
		line-height: 3.5vh;
		border-radius: 50%;
		border: 1px black solid;
		
	}
	.enjoy-4>li:hover{
		background: red;
	}
	.enjoy-4 a{
		color: black;
	}
	.artist{
		width: 100vw;
		height: 85vh;
	}
	.artist-1{
		width: 60vw;
		height: 50vh;
		margin: 0 auto;
		display: flex;
		justify-content: space-between;
	}
	.artist-11{
		width: 24vw;
		height: 50vh;
		background: orchid;
	}
	.artist-12{
		width: 36vw;
		height: 50vh;
		display: flex;
		justify-content: space-between;
		flex-wrap: wrap;
		align-items: center;
	}
	.artist-12>li{
		width: 12vw;
		height: 25vh;
	}
	.foot{
		width: 100vw;
		height: 40vh;
		margin-top: 2vh;
		background: black;	
	}
	.foot-11{
		width: 60vw;
		height: 8vh;
		margin: 0 auto;
	}
	.foot-11>img{
		display: block;
		height: 8vh;
		
	}
	.foot-12{
		width: 60vw;
		height: 25vh;
		margin: 0 auto;
		display: flex;
		justify-content: space-around;
		font-size: 0.7vw;
	}
	.foot-12>section>p{
		width: 12vw;
		height: 5vh;
		line-height: 5vh;
		font-size: 0.7vw;
	}
	.foot-12 ul{
		width: 12vw;
		height: 20vh;
	}
	.foot-12 ul>li{
		margin-top: 1vh;
	}
</style>
