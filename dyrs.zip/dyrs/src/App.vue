<template>
  <div id="app">
    <router-view/>
		<div class="nav">
			<!-- 第一个导航条 -->
			<div class="nav-1">
				<div class="nav-11">
					<Icon class="icon-1" type="ios-pin" size="15" />
					&nbsp;&nbsp;<p><span style="color: rgba(0, 0, 0, 0.5);">全国</span>&nbsp;&nbsp;<span>[切换]</span></p>
				</div>
				<ul class="nav-12">
					<li>注册即送1000元家装抵用券!</li>
					<li>注册</li>
					<li>登录</li>
					<li class="nav-124">
						<Icon type="md-call" />&nbsp;&nbsp;<span>咨询热线</span>&nbsp;&nbsp;&nbsp;<span>400-6600-598</span></li>
				</ul>
			</div>
			<!-- 第二个导航条 -->
			<div class="nav-2">
				<section class="nav-21"><img src="./assets/nac.png" alt="无法加载"></section>
				<section class="nav-22">
						
					<Menu mode="horizontal" theme="light" active-name="1" >
        <MenuItem name="1" to="/">
					首页     
        </MenuItem>
				 <MenuItem name="2">
        <Submenu name="2" >
            <template slot="title">
							装修服饰
            </template>
                <MenuItem name="2-1">个性化定制</MenuItem>
                <MenuItem name="2-2">别墅大宅</MenuItem>
                <MenuItem name="2-3">标准化套餐</MenuItem>
                <MenuItem name="2-4">全屋软装</MenuItem>
        </Submenu>
				</MenuItem>
				
        <Submenu name="3">
            <template slot="title">
						<router-link to="/aLi">
							  装修案例
						</router-link>
						 
            </template>
                <MenuItem name="3-1">灵感之源</MenuItem>
                <MenuItem name="3-2">热装楼盘</MenuItem>
                <MenuItem name="3-3">风格案例</MenuItem>
                <MenuItem name="3-4">案例图库</MenuItem>
                <MenuItem name="3-5">vr样板间</MenuItem>
								<MenuItem name="3-6">软装范本</MenuItem>
								<MenuItem name="3-7">在施工地</MenuItem>
								<MenuItem name="3-8">装修头条</MenuItem>
								<MenuItem name="3-9">3d设计</MenuItem>
        </Submenu>
			
      <Submenu name="4">
          <template slot="title">
              服务团队
          </template>
              <MenuItem name="4-1">团队定制服务</MenuItem>
              <MenuItem name="4-2">设计大师</MenuItem>
              <MenuItem name="4-3">金牌工队</MenuItem>
      </Submenu>
			<Submenu name="5">
			    <template slot="title">
			        品质护航
			    </template>
			        <MenuItem name="5-1">品牌保障</MenuItem>
			        <MenuItem name="5-2">前沿设计</MenuItem>
			        <MenuItem name="5-3">全球选材</MenuItem>
							<MenuItem name="5-4">欧系工艺</MenuItem>
							<MenuItem name="5-5">良心工程</MenuItem>
							<MenuItem name="5-6">完好交付</MenuItem>
							<MenuItem name="5-7">全屋环保</MenuItem>
			</Submenu>
			<Submenu name="6">
			    <template slot="title">
			        客户服务
			    </template>
			        <MenuItem name="6-1">预约装修服务</MenuItem>
			        <MenuItem name="6-2">装修礼包</MenuItem>
			        <MenuItem name="6-3">客户关怀</MenuItem>
							<MenuItem name="6-4">售后服务</MenuItem>
							<MenuItem name="6-5">客户评价</MenuItem>
							<MenuItem name="6-6">常见问题</MenuItem>
			</Submenu>
				<Submenu name="7">
			    <template slot="title">
			       关于东易
			    </template>
			        <MenuItem name="7-1">东易之道</MenuItem>
			        <MenuItem name="7-2">东易之路</MenuItem>
			        <MenuItem name="7-3">荣耀东易</MenuItem>
							<MenuItem name="7-4">爱心东易</MenuItem>
							<MenuItem name="7-5">东易新闻</MenuItem>
							<MenuItem name="7-6">视频东易</MenuItem>
							<MenuItem name="7-7">加入东易</MenuItem>
							<MenuItem name="7-8">联系东易</MenuItem>
			</Submenu>
			<MenuItem name="8">
			       线下体验馆
			</MenuItem>
    </Menu>
					
					<p>
						<Icon type="ios-search" class="nav-222" />
					</p>
				</section>
			</div>
		</div>
  </div>
</template>

<style scoped>
	* {
		box-sizing: border-box;
	}
	body {
		margin: 0;
	}

	ul {
		margin: 0;
		padding: 0;
	}

	li {
		list-style: none;
	}

	p {
		margin: 0;
	}
	a{
		color:black
	}
  /* 第一个导航条 */
	.nav{
		width: 100vw;
		height: 23vh;
		position: fixed;
		top: 0;
		z-index: 500;
		background: white;
	}
	.nav-1 {
		width: 100vw;
		height: 8vh;
		background: whitesmoke;
		display: flex;
		justify-content: space-around;
		align-items: center;
		font-size: 15px;
	}

	.nav-11 {
		width: 10vw;
		height: 8vh;
		display: flex;
		line-height: 8vh;
	}

	.icon-1 {
		position: relative;
		top: 2.8vh;
		color: rgba(0, 0, 0, 0.5);
	}

	.nav-12 {
		width: 25vw;
		height: 8vh;
		display: flex;
		justify-content: space-between;
		line-height: 8vh;
		cursor: pointer;
	}

	.nav-12>li {
		color: rgba(0, 0, 0, 0.5);
	}

	.nav-124 {
		color: red !important;
	}

	.nav-12>li:hover {
		color: red;
	}
 /* 第二个导航条 */
	.nav-2 {
		width: 100vw;
		height: 15vh;
		display: flex;
		justify-content: center;
		align-items: center;
		font-size: 15px;
		cursor: pointer;
	}
	.nav-2>section {
		line-height: 15vh;
	}

	.nav-21 {
		width: 15vw;
		height: 15vh;
		display: flex;
		justify-content: center;
		align-items: center;
	}
  .nav-21>img{
		display: block;
		width: 80%;
		
	}
	.nav-22 {
		width: 55vw;
		height: 15vh;
		display: flex;
		justify-content: space-between;
		align-items: center;
	}

	.nav-221 {
		display: block;
		width: 3vw;
		height: 8vh;
		line-height: 8vh;
		text-align: center;
		color: red;
		border-bottom: 2px solid red;
	}

	.nav-222 {
		position: relative;
		font-size: 25px;

	}

	.nav-23 {
		width: 5vw;
		height: 5vh;
		line-height: 5vh !important;
		text-align: center;
		border-radius: 15px;
		background: red;
		color: white;
	}
	.ivu-menu-child-item-active  a{
		color: royalblue !important;
	}

	.nav-22>p {
		width: 3vw;
		height: 8vh;
		line-height: 8vh;
	}
	.list-1 {
		width: 5vw;
		height: 5vh;
		line-height: 3vh;
		font-size: 18px;
	}
</style>
